package com.lnd.web.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@SpringBootTest
@ContextConfiguration(classes = {LndApplicationTests.class, TestConfig.class})
class LndApplicationTests {

	@Test
	void contextLoads() {
	}

}
