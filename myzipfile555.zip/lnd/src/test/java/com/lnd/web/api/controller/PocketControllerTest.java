package com.lnd.web.api.controller;

import com.lnd.web.api.model.Pocket;
import com.lnd.web.api.model.TnModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = {TestContainersConfig.class})
public class PocketControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @BeforeEach
    void setUp() {
        // Initialize test data if needed
    }

    @Test
    void testCreditPocketById() {
        TnModel tnModel = new TnModel();
        tnModel.setAmount(100L);
        tnModel.setTnId("asdasdasd");

        webTestClient.post()
                .uri("/api/pockets/{id}/credit", "1")
                .contentType(MediaType.APPLICATION_JSON)
                .body(Mono.just(tnModel), TnModel.class)
                .exchange()
                .expectStatus().is2xxSuccessful()
                .expectBody(Pocket.class)
                .value(pocket -> {
                    assertNotNull(pocket.getId());
                    assertEquals("1", pocket.getId());
//                    assertEquals(100L, pocket.getBalance());
                    assertNotNull(pocket.getCreatedDate());
//                    assertEquals(1, pocket.getVersion());
                    assertNull(pocket.getLastTnId());
                    // Add assertions here
                });
    }
}