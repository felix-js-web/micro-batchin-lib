package com.lnd.web.api.controller;

import com.lnd.web.api.model.Pocket;
import com.lnd.web.api.model.PocketTxn;
import com.lnd.web.api.model.TnModel;
import com.lnd.web.api.service.PocketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class PocketController {
    private final PocketService pocketService;

    public PocketController(PocketService pocketService) {
        this.pocketService = pocketService;
    }

    //dummy endpoint only for testing  - turn off further
    @GetMapping("/pockets")
    @ResponseStatus(HttpStatus.OK)
    public Flux<Pocket> getAll() {
        return pocketService.findAll();
    }

    //dummy endpoint only for testing  - turn off further
    @GetMapping("/tns")
    @ResponseStatus(HttpStatus.OK)
    public Flux<PocketTxn> getAllTxn() {
        return pocketService.findAllTns();
    }

    @GetMapping("/pockets/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Mono<ResponseEntity<Pocket>> getPocketById(@PathVariable("id") String id) {
        return pocketService.findById(id)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

//    @PostMapping("/pockets/{id}/debit")
//    @ResponseStatus(HttpStatus.CREATED)
//    public Mono<ResponseEntity<Pocket>> debitPocketById(@PathVariable("id") String id,
//                                                        @RequestBody TnModel tnModel) {
//        return pocketService.findById(id)
//                .map(ResponseEntity::ok)
//                .defaultIfEmpty(ResponseEntity.notFound().build());
//    }

    @PostMapping("/pockets/{id}/credit")
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<ResponseEntity<Pocket>> creditPocketById(@PathVariable("id") String id,
                                                         @RequestBody TnModel tnModel) {
        return pocketService.creditById(id, tnModel)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

//    @PostMapping("/tutorials")
//    @ResponseStatus(HttpStatus.CREATED)
//    public Mono<Tutorial> createTutorial(@RequestBody Tutorial tutorial) {
//        return tutorialService.save(new Tutorial(tutorial.getTitle(), tutorial.getDescription(), false));
//    }
//
//    @PutMapping("/tutorials/{id}")
//    @ResponseStatus(HttpStatus.OK)
//    public Mono<Tutorial> updateTutorial(@PathVariable("id") int id, @RequestBody Tutorial tutorial) {
//        return tutorialService.update(id, tutorial);
//    }
//
//    @DeleteMapping("/tutorials/{id}")
//    @ResponseStatus(HttpStatus.NO_CONTENT)
//    public Mono<Void> deleteTutorial(@PathVariable("id") int id) {
//        return tutorialService.deleteById(id);
//    }
//
//    @DeleteMapping("/tutorials")
//    @ResponseStatus(HttpStatus.NO_CONTENT)
//    public Mono<Void> deleteAllTutorials() {
//        return tutorialService.deleteAll();
//    }
//
//    @GetMapping("/tutorials/published")
//    @ResponseStatus(HttpStatus.OK)
//    public Flux<Tutorial> findByPublished() {
//        return tutorialService.findByPublished(true);
//    }
}