package com.lnd.web.api.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Pocket {

    @Id
    private String id;

    @CreatedDate
    private LocalDateTime createdDate;

    private Long coins;

    private Byte version;

    @Column("last_tn_id")
    private String lastTnId;

}