package com.lnd.web.api.repository;

import com.lnd.web.api.model.PocketTxn;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PocketTxnRepository extends ReactiveCrudRepository<PocketTxn, String> {
}