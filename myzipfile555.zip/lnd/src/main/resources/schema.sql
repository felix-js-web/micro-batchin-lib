drop table IF EXISTS  pocket;

CREATE TABLE pocket (
    id VARCHAR(50) PRIMARY KEY,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    coins BIGINT DEFAULT 0,
    version INT DEFAULT 1,
    last_tn_id VARCHAR(50)
);


INSERT INTO pocket (id) VALUES ('1');
INSERT INTO pocket (id) VALUES ('2');
INSERT INTO pocket (id) VALUES ('3');

DROP TABLE IF EXISTS pocket_txn;

DROP TABLE IF EXISTS pocket_txn;

CREATE TABLE pocket_txn (
    id SERIAL PRIMARY KEY,
    tn_id VARCHAR(50),
    pocket_id VARCHAR(50),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    tn_type CHAR(1) CHECK (tn_type IN ('D', 'C')),
    amount BIGINT,
    UNIQUE (tn_id, pocket_id)
);

INSERT INTO pocket_txn (tn_id, pocket_id, tn_type, amount) VALUES ('tn1','1','C',12000);
INSERT INTO pocket_txn (tn_id, pocket_id, tn_type, amount) VALUES ('tn2','1','C',15000);
INSERT INTO pocket_txn (tn_id, pocket_id, tn_type, amount) VALUES ('tn3','1','C',15000);
INSERT INTO pocket_txn (tn_id, pocket_id, tn_type, amount) VALUES ('tn4','1','D',18000);