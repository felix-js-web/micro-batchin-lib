package com.lnd.web.api.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@Table("pocket_txn")
@AllArgsConstructor
public class PocketTxn {

    @Id
    private Long id; // Auto-generated unique ID

    @Column("tn_id")
    private String tnId;

    @Column("pocket_id")
    private String pocketId;

    @Column("tn_type")
    private char tnType; // 'D' for debit, 'C' for credit

    @Column("amount")
    private Long amount;

    @CreatedDate
    private LocalDateTime createdDate;

}