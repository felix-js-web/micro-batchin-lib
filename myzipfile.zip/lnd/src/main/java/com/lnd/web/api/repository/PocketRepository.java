package com.lnd.web.api.repository;

import com.lnd.web.api.model.Pocket;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import org.springframework.stereotype.Repository;
@Repository
public interface PocketRepository extends R2dbcRepository<Pocket, String> {
}