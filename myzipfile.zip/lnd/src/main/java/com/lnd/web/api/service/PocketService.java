package com.lnd.web.api.service;

import java.util.Optional;

import com.lnd.web.api.model.Pocket;
import com.lnd.web.api.model.PocketTxn;
import com.lnd.web.api.model.TnModel;
import com.lnd.web.api.repository.PocketRepository;
import com.lnd.web.api.repository.PocketTxnRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;


@Service
public class PocketService {

    @Autowired
    PocketRepository pocketRepository;
    @Autowired
    PocketTxnRepository pocketTxnRepository;

    public PocketService(PocketRepository pocketRepository,
                         PocketTxnRepository pocketTxnRepository) {
        this.pocketRepository = pocketRepository;
        this.pocketTxnRepository = pocketTxnRepository;
    }


    public Flux<Pocket> findAll() {
        return pocketRepository.findAll();
    }

    public Flux<PocketTxn> findAllTns() {
        return pocketTxnRepository.findAll();
    }

    public Mono<Pocket> findById(String id) {
        return pocketRepository.findById(id);
    }

    public Mono<Pocket> creditById(String id, TnModel tnModel) {
        return pocketRepository.findById(id);
    }

//    public Mono<Pocket> findById(int id) {
//        return tutorialRepository.findById(id);
//    }
//
//    public Mono<Tutorial> save(Tutorial tutorial) {
//        return tutorialRepository.save(tutorial);
//    }
//
//    public Mono<Tutorial> update(int id, Tutorial tutorial) {
//        return tutorialRepository.findById(id).map(Optional::of).defaultIfEmpty(Optional.empty())
//                .flatMap(optionalTutorial -> {
//                    if (optionalTutorial.isPresent()) {
//                        tutorial.setId(id);
//                        return tutorialRepository.save(tutorial);
//                    }
//
//                    return Mono.empty();
//                });
//    }
//
//    public Mono<Void> deleteById(int id) {
//        return tutorialRepository.deleteById(id);
//    }
//
//    public Mono<Void> deleteAll() {
//        return tutorialRepository.deleteAll();
//    }
//
//    public Flux<Tutorial> findByPublished(boolean isPublished) {
//        return tutorialRepository.findByPublished(isPublished);
//    }
}