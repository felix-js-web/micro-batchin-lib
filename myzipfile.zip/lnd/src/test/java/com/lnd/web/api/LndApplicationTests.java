package com.lnd.web.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LndApplicationTests {

	@Test
	void contextLoads() {
	}

}
