https://start.spring.io/
https://www.code4it.dev/blog/run-postgresql-with-docker/

DBEAVER connect
CREATE DATABASE WALLET;

https://github.com/bezkoder/spring-data-r2dbc-postgresql-example/blob/master/src/main/java/com/bezkoder/spring/r2dbc/postgresql/service/TutorialService.java
https://www.postgresql.org/docs/current/sql-createdatabase.html

https://www.baeldung.com/intro-to-project-lombok

https://projectlombok.org/setup/gradle


https://stackoverflow.com/questions/13357487/how-to-map-postgresql-timestamp-with-time-zone-in-a-jpa-2-entity

